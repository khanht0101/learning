/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Compiler;

/**
 *
 * @author Khanh
 */
public class ResultTestcase 
{
    public void Testcase(){}
    public String caseDesc;
    public boolean  status;
    public String result;
    
}
