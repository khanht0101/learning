/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Compiler;
import zbse20.NTSMain;

/**
 *
 * @author Khanh
 */
public class TestCode 
{
    NTSMain NTS_SE = new NTSMain();
    public void Print(String message, boolean newLine)
    {
        
    }
    
    
}
