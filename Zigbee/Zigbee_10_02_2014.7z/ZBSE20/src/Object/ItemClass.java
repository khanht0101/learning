/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Object;

/**
 *
 * @author Khanh
 */
public class ItemClass 
{
    public ItemClass()
    {}
    public void DoTest()
    {
        System.out.println("Do test eval function");
    }
    public String GetTest()
    {
        return "Test eval function";
    }
    
}
