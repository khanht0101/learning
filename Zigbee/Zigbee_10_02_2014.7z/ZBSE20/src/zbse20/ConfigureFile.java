/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package zbse20;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Khanh
 */
public class ConfigureFile 
{
    public String deviceType ="";
    public String ConfigureSystemService = "";
    public String ConfigureNetWorkProtocol = "";
    public String ConfigurSimulatiedDevice ="";
    public List<FunctionSet> FunctionSets = new ArrayList<FunctionSet>();
}
