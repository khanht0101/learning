/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.Identification;

import com.PrimaryTypes.UInt16;
import java.io.Serializable;

/**
 *
 * @author CONG HUY
 */
public class ListLink implements Serializable
{
    public ListLink() {};
    public UInt16 all;
    
}
