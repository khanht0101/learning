/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.server;

import javax.swing.JTextArea;
import javax.swing.tree.DefaultMutableTreeNode;

/**
 *
 * @author CONG HUY
 */
public class DisplayConsole 
{
    public static JTextArea uiConsole;
    public static DefaultMutableTreeNode treeRoot;
       
}
