/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Time;

import com.Types.TimeType;
import com.Types.TimeOffsetType;
import java.io.Serializable;

/**
 *
 * @author CONG HUY
 */
public class Time implements Serializable
{
    public Time() {}
    public TimeType currentTime;
    public TimeType dstEndTime;
    public TimeOffsetType dstOffset;
}
