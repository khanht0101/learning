/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package FunctionSetAssignments;

import com.PrimaryTypes.String32;
import com.Types.VersionType;
import com.Types.mRIDType;
import com.Types.SubscribableType;
import com.PrimaryTypes.*;
import java.io.Serializable;

/**
 *
 * @author CONG HUY
 */
public class FunctionSetAssignments implements Serializable
{
    public FunctionSetAssignments (){}
    public String32 description = new String32("Usage Point");
    public mRIDType mRID = new mRIDType();
    public SubscribableType subscribable = new SubscribableType() ;
    public VersionType version = new VersionType() ;
    public mRIDType getmRIDTypeObject()
    {
        return mRID;
    }
    public SubscribableType getsubscribableTypeObject()
    {
        return subscribable;
    }
    public VersionType getversionTypeObject()
    {
        return version;
    }

}
