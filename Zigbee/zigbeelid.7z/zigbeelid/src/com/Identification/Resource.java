/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.Identification;

import com.Types.anyURI;
import java.io.Serializable;

/**
 *
 * @author CONG HUY
 */
public class Resource implements Serializable
{
    public Resource() {}
    public anyURI href;
    
}
