/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.DeviceType;

import java.io.Serializable;

/**
 *
 * @author CONG HUY
 */
public enum  DeviceType implements Serializable
{
    Metering,
    Messaging,
    Pricing,
    Billing,
    Prepayment
    
}
