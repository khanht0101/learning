/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Configuration;

import com.PrimaryTypes.String32;
import com.Types.LocaleType;
import com.PrimaryTypes.*;
import java.io.Serializable;

/**
 *
 * @author CONG HUY
 */
public class Configuration implements Serializable
{
    public Configuration() {}
    public LocaleType currentLocale;
    public String32 userDeviceName;
    
}
