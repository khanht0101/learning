/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Configuration;

import com.Types.DstRuleType;
import com.Types.TimeOffsetType;
import java.io.Serializable;

/**
 *
 * @author CONG HUY
 */
public class TimeConfiguration implements Serializable
{
    public TimeConfiguration() {}
    public DstRuleType dstEndRule;
    public TimeOffsetType dstOffset;
    public DstRuleType dstStartRult;
    public TimeOffsetType tzOffset;
}
