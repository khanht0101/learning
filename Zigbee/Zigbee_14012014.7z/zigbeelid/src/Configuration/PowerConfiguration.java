/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Configuration;

import com.PrimaryTypes.UInt32;
import com.Types.TimeType;
import com.PrimaryTypes.*;
import java.io.Serializable;

/**
 *
 * @author CONG HUY
 */
public class PowerConfiguration implements Serializable
{
    public PowerConfiguration() {}
    public TimeType batteryInstallTime;
    public UInt32 lowChargeThreshold;
    
}
