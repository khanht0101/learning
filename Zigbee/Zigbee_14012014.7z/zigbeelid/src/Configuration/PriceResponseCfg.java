/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Configuration;

import com.PrimaryTypes.*;
import java.io.Serializable;

/**
 *
 * @author CONG HUY
 */
public class PriceResponseCfg implements Serializable
{
    public PriceResponseCfg () {}
    public Int32 consumeThreshold;
    public Int32 maxReductionThreshold;
    
}
