/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.user;

import java.io.Serializable;

/**
 *
 * @author khanhnguyenc
 */
public class DeviceInfo implements  Serializable
{
    
    public DeviceInfo()
    {}
    public String Name;
    public String IP; 
    public int Port;
}
