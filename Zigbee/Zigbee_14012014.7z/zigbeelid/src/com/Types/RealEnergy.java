/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.Types;

import com.PrimaryTypes.UInt48;
import com.PrimaryTypes.*;
import java.io.Serializable;
import java.util.Random;

/**
 *
 * @author CONG HUY
 */
public class RealEnergy implements Serializable
{
    public RealEnergy() 
    {
        Random random = new Random();
        multiplier = new PowerOfTenMultiplierType(random.nextLong());
        value = new UInt48(random.nextInt(48));
    }
    public PowerOfTenMultiplierType multiplier;
    public void setValue(UInt48 _value)
    {
        value = _value;
    }
    public UInt48 getValue()
    {
        return value;
    }
    public UInt48 value;
    
}
