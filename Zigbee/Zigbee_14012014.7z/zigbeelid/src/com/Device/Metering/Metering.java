/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.Device.Metering;
import java.io.Serializable;
/**
 *
 * @author CONG HUY
 */
public class Metering implements Serializable
{
    public Metering()
    {
    }
    public int Id;
    public String Name;
    public int Value;
    
}
