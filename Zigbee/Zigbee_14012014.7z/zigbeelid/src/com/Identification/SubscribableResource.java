/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.Identification;

import com.Types.SubscribableType;
import java.io.Serializable;

/**
 *
 * @author CONG HUY
 */
public class SubscribableResource implements Serializable
{
    public SubscribableResource () {}
    public SubscribableType subscribable;
    
}
