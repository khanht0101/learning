/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package DeviceStatus;

import java.io.Serializable;
import java.util.List;

/**
 *
 * @author CONG HUY
 */
public class EndDeviceList implements Serializable
{
    public EndDeviceList() {}
    public List<EndDevice> endDeviceList;
}
