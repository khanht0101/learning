/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package DeviceStatus;

import com.Types.PINType;
import java.io.Serializable;

/**
 *
 * @author CONG HUY
 */
public class Registration implements Serializable
{
    public Registration () {}
    public PINType pIN = new PINType();
    
}
