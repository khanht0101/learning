/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package DeviceStatus;

import com.PrimaryTypes.UInt8;
import com.Types.PowerOfTenMultiplierType;
import java.io.Serializable;

/**
 *
 * @author CONG HUY
 */
public class Temperature implements Serializable
{
    public Temperature  () {}
    public PowerOfTenMultiplierType multiplier;
    public UInt8 subject;
}
