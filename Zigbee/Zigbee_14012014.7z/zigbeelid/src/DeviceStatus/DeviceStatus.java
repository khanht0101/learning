/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package DeviceStatus;

import com.PrimaryTypes.UInt16;
import com.Types.TimeType;
import java.io.Serializable;

/**
 *
 * @author CONG HUY
 */
public class DeviceStatus implements Serializable
{
    public DeviceStatus() {}
    public TimeType  changedTime = new  TimeType();
    public UInt16 onCount = new UInt16(1);
}
