/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Response;

import com.PrimaryTypes.UInt16;
import java.io.Serializable;

/**
 *
 * @author CONG HUY
 */
public class DrResponse implements Serializable
{
    public DrResponse  () {}
    public UInt16 overrideDuration;
    
}
