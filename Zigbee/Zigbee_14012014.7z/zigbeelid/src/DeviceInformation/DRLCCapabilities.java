
/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package DeviceInformation;

import com.Types.RealEnergy;
import com.Types.ActivePower;
import com.PrimaryTypes.HexBinary32;
import java.io.Serializable;

/**
 *
 * @author CONG HUY
 */
public class DRLCCapabilities implements Serializable
{
    public DRLCCapabilities () {}
    public RealEnergy averageEnergy;
    public ActivePower maxDemand;
    public HexBinary32 optionsImplemented;
    
}
