/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package DeviceInformation;

import com.Types.LocaleType;
import java.io.Serializable;

/**
 *
 * @author CONG HUY
 */
public class SupportedLocale implements Serializable
{
    public SupportedLocale () {}
    public LocaleType locale;
}
