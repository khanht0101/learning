/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package DeviceInformation;

import com.PrimaryTypes.HexBinary160;
import com.PrimaryTypes.HexBinary64;
import com.PrimaryTypes.*;
import java.io.Serializable;

/**
 *
 * @author CONG HUY
 */
public class DeviceInformation implements Serializable
{
    public DeviceInformation() {}
    public HexBinary64 functionsImplemented = new HexBinary64();
    public HexBinary160 IFDI = new HexBinary160(98765432);
    public String configureSystemService = "";
    public String configureNetworkProtocal = "";
    public String configureSimulatedDevice = ""; 
    public HexBinary160 getIFDIObject()
    {
        return IFDI;
    }
    public HexBinary64 getfuncionsImplementedObject()
    {
        return functionsImplemented;
    }
}
