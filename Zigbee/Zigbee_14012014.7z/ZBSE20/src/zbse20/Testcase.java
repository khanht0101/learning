/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package zbse20;

/**
 *
 * @author CONG HUY
 */
public class Testcase 
{
    String functionset = "";
    String server = "";
    String required = "";
    String name = "";
    String description = "";
    String command = "";
    String fileName = "";
    String status = "N";
    
}
